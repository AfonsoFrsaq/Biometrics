import numpy as np
import os
import librosa
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

# Define paths to train and test subsets
train_path = r"c:\Users\anton\Documents\Erasmus\Biometrics\Lab5\Voice Dataset\train"
test_path = r"c:\Users\anton\Documents\Erasmus\Biometrics\Lab5\Voice Dataset\test"

# Function for data preprocessing
def preprocess_data(data):
    # Perform feature scaling
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(data)
    return scaled_data

# Function to extract MFCC features and fit GMM
def train_voice_recognition(train_path, n_mfcc=45, n_components=26):
    gmm_models = []
    for filename in os.listdir(train_path):
        if filename.endswith('.wav'):
            filepath = os.path.join(train_path, filename)
            # Load recording
            y, sr = librosa.load(filepath, sr=None)
            # Extract MFCC features
            mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
            mfcc = mfcc.T  # Transpose to form row vector
            # Preprocess MFCC features
            mfcc = preprocess_data(mfcc)
            # Fit GMM
            gmm = GaussianMixture(n_components=n_components, random_state=0)
            gmm.fit(mfcc)
            gmm_models.append(gmm)
    return gmm_models

# Function to classify test recordings
def test_voice_recognition(test_path, gmm_models):
    true_labels = []
    predicted_labels = []
    for filename in os.listdir(test_path):
        if filename.endswith('.wav'):
            true_label = int(filename[1])  # Extract true label from filename
            true_labels.append(true_label)
            filepath = os.path.join(test_path, filename)
            # Load and extract MFCC
            y, sr = librosa.load(filepath, sr=None)
            mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=45)
            mfcc = mfcc.T
            # Preprocess MFCC features
            mfcc = preprocess_data(mfcc)
            # Classify using GMMs
            max_score = -np.inf
            detected_speaker = None
            for i, gmm in enumerate(gmm_models):
                score = gmm.score(mfcc)
                if score > max_score:
                    max_score = score
                    detected_speaker = i + 1  # Speaker index starts from 1
            predicted_labels.append(detected_speaker)
            print(f"Detected speaker for {filename}: Speaker {detected_speaker}, Score: {max_score}")
    # Calculate accuracy
    accuracy = accuracy_score(true_labels, predicted_labels)
    print(f"Overall accuracy: {accuracy}")

# Train voice recognition system
gmm_models = train_voice_recognition(train_path)

# Test voice recognition system
test_voice_recognition(test_path, gmm_models)
