import os
import cv2
import numpy as np

from typing import Tuple, List

def remove_glare(image: np.ndarray) -> Tuple[np.ndarray, int, int]:
    H = cv2.calcHist([image], [0], None, [256], [0, 256])
    # plt.plot(H[150:])
    # plt.show()
    idx = np.argmax(H[150:]) + 151
    binary = cv2.threshold(image, idx, 255, cv2.THRESH_BINARY)[1]

    st3 = np.ones((3, 3), dtype="uint8")
    st7 = np.ones((7, 7), dtype="uint8")

    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, st3)
    binary = cv2.morphologyEx(binary, cv2.MORPH_DILATE, st3, iterations=2)

    im_floodfill = binary.copy()

    h, w = im_floodfill.shape[:2]
    mask = np.zeros((h + 2, w + 2), np.uint8)

    cv2.floodFill(im_floodfill, mask, (0, 0), 255)

    im_floodfill_inv = cv2.bitwise_not(im_floodfill)
    im_out = binary | im_floodfill_inv
    im_out = cv2.morphologyEx(im_out, cv2.MORPH_DILATE, st7, iterations=1)
    _, _, stats, cents = cv2.connectedComponentsWithStats(im_out)
    cx, cy = 0, 0
    for st, cent in zip(stats, cents):
        if 1500 < st[4] < 3000:
            if 0.9 < st[2] / st[3] < 1.1:
                cx, cy = cent.astype(int)
                r = st[2] // 2
                cv2.circle(image, (cx, cy), r, (125, 125, 125), thickness=2)

    image = np.where(im_out, 64, image)
    image = cv2.medianBlur(image, 5)

    return image, cx, cy
def exploding_circle_algorithm(image: np.ndarray, cx: int, cy: int, initial_radius: int, step: int, max_radius: int) -> Tuple[int, int, int]:
    # Implement the Exploding Circle Algorithm here
    optimal_radius = initial_radius
    best_change = 0
    best_cx = cx
    best_cy = cy

    for x in range(cx - 1, cx + 2):
        for y in range(cy - 1, cy + 2):
            for radius in range(initial_radius, max_radius, step):
                change = compute_brightness_change(image, x, y, radius)
                if change > best_change:
                    best_change = change
                    optimal_radius = radius
                    best_cx = x
                    best_cy = y

    return optimal_radius, best_cx, best_cy

def compute_brightness_change(image: np.ndarray, x: int, y: int, radius: int) -> float:
    # Compute the brightness change for a given circle
    brightness_sum = 0
    prev_brightness = 0
    for angle in range(0, 360, 5):
        px = int(x + radius * np.cos(np.radians(angle)))
        py = int(y + radius * np.sin(np.radians(angle)))
        brightness = image[py, px]
        brightness_sum += brightness
        if angle != 0:
            change = abs(brightness - prev_brightness)
            prev_brightness = brightness
            return change
        prev_brightness = brightness

def generate_gabor_kernels():
    kernels = []
    sigma = 2
    for theta in range(8):
        t = theta / 8. * np.pi
        kernel = gabor_kernel(0.15, theta=t, sigma_x=sigma, sigma_y=sigma)
        kernels.append(kernel)
    return kernels

def apply_gabor_filters(image: np.ndarray, sample_points: List[Tuple[int, int]], kernels: List[np.ndarray]) -> str:
    iris_code = ""
    for point in sample_points:
        x, y = point
        patch = image[y-10:y+11, x-10:x+11]
        code = ""
        for kernel in kernels:
            real_part = cv2.filter2D(patch, -1, np.real(kernel))
            imag_part = cv2.filter2D(patch, -1, np.imag(kernel))
            if np.mean(real_part) > 0:
                code += "1"
            else:
                code += "0"
            if np.mean(imag_part) > 0:
                code += "1"
            else:
                code += "0"
        iris_code += code
    return iris_code

def main(data_path: str) -> None:
    filename_list = [f for f in os.listdir(data_path) if os.path.isfile(os.path.join(data_path, f))]

    for filename in filename_list:
        img = cv2.imread(os.path.join(data_path, filename))
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img_no_glare, x, y = remove_glare(gray)

        optimal_radius, pupil_center_x, pupil_center_y = exploding_circle_algorithm(img_no_glare, x, y, initial_radius=75, step=5, max_radius=200)

        sample_points = [(pupil_center_x + i, pupil_center_y + j) for i in range(-7, 8, 2) for j in range(-7, 8, 2)]
        kernels = generate_gabor_kernels()
        iris_code = apply_gabor_filters(img_no_glare, sample_points, kernels)

if __name__ == "__main__":
    data_path = "c:\Users\nicol\Desktop\ERASMUS\Biometrics\Lab5-iris\iris_database_train"
    main(data_path)
