import cv2
import os
import argparse
import numpy as np
from tqdm import tqdm
from sklearn.metrics import classification_report
from typing import List, Tuple

def read_img_paths(dir: str) -> List[str]:
    """
    Read image file names from the given directory and return as a list of str: "dir/name.tif"
    """
    filename_list: List[str] = []

    # Get the list of files in the directory
    files = os.listdir(dir)

    # Filter out only the files ending with ".tif"
    for file in files:
        if file.endswith(".tif"):
            # Construct the full path to the file
            file_path = os.path.join(dir, file)
            filename_list.append(file_path)

    return filename_list

def img_preprocessing(path: str) -> np.ndarray:
    """
    Read image from file and convert to grayscale
    """
    # Read the image from the path
    img = cv2.imread(path)

    # Convert the image to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    return gray

def get_features(gray: np.ndarray, alg_type: str) -> Tuple[List[np.ndarray], List[np.ndarray]]:
    """
    Compute keypoints locations and their descriptors
    """
    assert alg_type == "sift" or alg_type == "orb", "Algorithm type must be 'sift' or 'orb'"
    kp: List[np.ndarray] = []
    dsc: List[np.ndarray] = []

    # Create the feature detector based on the algorithm type
    if alg_type == "sift":
        detector = cv2.SIFT_create()
    elif alg_type == "orb":
        detector = cv2.ORB_create()

    # Detect keypoints and compute descriptors
    kp, dsc = detector.detectAndCompute(gray, None)

    return kp, dsc

def match_fingerprints(
    features2match: dict, features_base: dict, alg_type: str, m_coeff=0.75
) -> Tuple[List[str], List[str]]:
    """
    Match features and gather stats
    """
    assert alg_type == "sift" or alg_type == "orb", "Algorithm type must be 'sift' or 'orb'"
    y_pred: List[str] = []
    y_test: List[str] = []

    # Create proper DescriptorMatcher based on algorithm type
    if alg_type == "sift":
        matcher = cv2.BFMatcher(cv2.NORM_L2)
    elif alg_type == "orb":
        matcher = cv2.BFMatcher(cv2.NORM_HAMMING)

    # Iterate over features to match
    for id_finger, features in features2match.items():
        # Get features for current finger from feature_base
        if id_finger in features_base:
            base_features = features_base[id_finger][alg_type]
            # Iterate over each feature in features2match
            for feature in features[alg_type]:
                best_match_num = 0
                best_match_id = None
                # Shuffle the base features to introduce randomness
                np.random.shuffle(base_features)
                # Iterate over shuffled database features
                for base_feature in base_features:
                    # Match features
                    matches = matcher.knnMatch(feature, base_feature, k=2)
                    good_matches_num = 0
                    for m, n in matches:
                        if m.distance < m_coeff * n.distance:
                            good_matches_num += 1
                    # Store the number of good matches for each database sample
                    if good_matches_num > best_match_num:
                        best_match_num = good_matches_num
                        best_match_id = id_finger
                # Append the predicted and ground truth labels
                y_pred.append(best_match_id)
                y_test.append(id_finger)

    return y_pred, y_test

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=str)
    args = parser.parse_args()

    # Read filepaths
    filepaths = read_img_paths(args.path)

    # Get features
    features_base = dict()
    features2match = dict()
    for path in tqdm(filepaths):
        gray = img_preprocessing(path)
        kp_sift, dsc_sift = get_features(gray, "sift")
        kp_orb, dsc_orb = get_features(gray, "orb")

        # Split features into database and suspects
        filename = os.path.basename(path)[:-4]  # Remove file extension
        id_finger, id_sample = filename.split("_")

        # If id_sample equals "1", add to feature_base, else add to features2match
        if id_sample == "1":
            features_base.setdefault(id_finger, {"sift": [], "orb": []})
            features_base[id_finger]["sift"].append(dsc_sift)
            features_base[id_finger]["orb"].append(dsc_orb)
        else:
            features2match.setdefault(id_finger, {"sift": [], "orb": []})
            features2match[id_finger]["sift"].append(dsc_sift)
            features2match[id_finger]["orb"].append(dsc_orb)

    # Match features
    preds, gt = match_fingerprints(features2match, features_base, "sift")
    print("--- SIFT ---")
    if preds and gt:
        y_pred_filtered = [pred for pred, truth in zip(preds, gt) if pred is not None]
        y_test_filtered = [truth for pred, truth in zip(preds, gt) if pred is not None]
        print(classification_report(y_test_filtered, y_pred_filtered))
    else:
        print("No valid predictions available.")

    preds, gt = match_fingerprints(features2match, features_base, "orb")
    print("--- ORB ---")
    if preds and gt:
        y_pred_filtered = [pred for pred, truth in zip(preds, gt) if pred is not None]
        y_test_filtered = [truth for pred, truth in zip(preds, gt) if pred is not None]
        print(classification_report(y_test_filtered, y_pred_filtered))
    else:
        print("No valid predictions available.")
