import cv2
import numpy as np
import os
import sys

def process_image(img_path):

    img = cv2.imread(img_path)
    
  
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    img_floodfill = img_gray.copy()
    h, w = img_floodfill.shape[:2]
    floodfill_mask = np.zeros((h+2, w+2), np.uint8)
    cv2.floodFill(img_floodfill, floodfill_mask, (0, 0), 255)
    img_floodfill_inv = cv2.bitwise_not(img_floodfill)
    img_mask = img_floodfill_inv | img_gray
 
    dil_kernel = np.ones((13, 13), np.uint8)
    img_dilated = cv2.dilate(img_mask, dil_kernel, iterations=1)
    
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    img_clahe = clahe.apply(img_gray)
    img_clahe_inv = 255 - img_clahe
    img_clahe_final = clahe.apply(img_clahe_inv)
    
    img_blurred = cv2.GaussianBlur(img_clahe_final, (7, 7), 1.5)

    img_thresh = cv2.adaptiveThreshold(img_blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                       cv2.THRESH_BINARY, 11, 2)
    img_combined = cv2.bitwise_and(img_thresh, img_dilated)

    img_median = cv2.medianBlur(img_combined, 5)
    img_inverted = cv2.bitwise_not(img_median)
    
    img_closed = cv2.morphologyEx(img_inverted, cv2.MORPH_CLOSE, dil_kernel)
    img_closed_inv = cv2.bitwise_not(img_closed)
 
    nb_components, output, stats, centroids = cv2.connectedComponentsWithStats(img_closed_inv, connectivity=8)
    sizes = stats[1:, -1]
    nb_components = nb_components - 1
    img_filtered = np.zeros((output.shape), np.uint8)
    for i in range(0, nb_components):
        if sizes[i] >= 500:
            img_filtered[output == i + 1] = 255

    skel_element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    skel = np.zeros(img_filtered.shape, np.uint8)
    img_obj_filtered = img_filtered.copy()

    while True:
        opened = cv2.morphologyEx(img_obj_filtered, cv2.MORPH_OPEN, skel_element)
        temp = cv2.subtract(img_obj_filtered, opened)
        eroded = cv2.erode(img_obj_filtered, skel_element)
        skel = cv2.bitwise_or(skel, temp)
        img_obj_filtered = eroded.copy()
        if cv2.countNonZero(img_obj_filtered) == 0:
            break
    
    return skel

def process_dataset(dataset_path):
    output_dir = os.path.join(dataset_path, 'output')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for filename in os.listdir(dataset_path):
        if filename.endswith('.jpg') or filename.endswith('.png'):
            img_path = os.path.join(dataset_path, filename)
            skel = process_image(img_path)
            output_path = os.path.join(output_dir, 'skel_' + filename)
            cv2.imwrite(output_path, skel)
            print(f'Processed {filename}, saved to {output_path}')

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python retina.py <dataset_path>")
        sys.exit(1)
    
    dataset_path = sys.argv[1]
    process_dataset(dataset_path)

