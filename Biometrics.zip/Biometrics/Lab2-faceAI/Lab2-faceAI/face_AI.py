import csv
import os
import argparse
import random
import numpy as np
import torch
from scipy.io import loadmat
from tqdm import tqdm
from facenet_pytorch import InceptionResnetV1
import cv2

from typing import Dict, List, Tuple

# Constants
N_FACES_THRESHOLD = 5
IMG_SIZE = 160  
TRAIN_FRAC = 0.8

def read_labels(csv_path: str) -> Dict[int, int]:
    """
    Read labels from Caltech database .csv file and return as dict {id: label}.
    """
    mydict: Dict[int, int] = {}
    with open(csv_path, 'r') as csvfile:
        reader = csv.reader(csvfile)
        for idx, row in enumerate(reader, start=1):
            label = int(row[0])
            mydict[idx] = label
    return mydict

def read_ROIs(path: str) -> np.ndarray:
    """
    Read ROI's array from a MAT file.
    """
    data = loadmat(path)
    if "SubDir_Data" in data:
        return data["SubDir_Data"]
    else:
        raise KeyError("Key 'SubDir_Data' not found in the MAT file.")

def read_img_paths(dir: str) -> List[str]:
    """
    Read image file names from the given directory and return as a list of str: "dir/name.jpg".
    """
    return [os.path.join(dir, file) for file in os.listdir(dir) if file.endswith('.jpg')]

def img_preprocessing(path: str, top_left: Tuple[int, int], bottom_right: Tuple[int, int]) -> torch.Tensor:
    """
    Preprocess images to use them as inputs to FaceNet.
    """
    img = cv2.imread(path)
    if img is None:
        raise ValueError(f"Image at path {path} could not be loaded.")
    # Crop to ROI
    x1, y1 = top_left
    x2, y2 = bottom_right
    cropped_img = img[y1:y2, x1:x2]
    # Resize to 160x160
    resized_img = cv2.resize(cropped_img, (IMG_SIZE, IMG_SIZE))
    # Normalize and convert to torch tensor
    roi_float = resized_img / 255.0
    roi_tensor = torch.from_numpy(roi_float).permute(2, 0, 1).float()
    return roi_tensor

def main(path: str):
    random.seed(7)

    # Read labels
    csv_path = os.path.join(path, "caltech_labels.csv")
    labels = read_labels(csv_path)

    # Read ROIs
    mat_path = os.path.join(path, "ImageData.mat")
    rois = read_ROIs(mat_path)

    # Read filenames
    filenames = read_img_paths(path)

    # Create train and test data
    train_images, train_labels, test_images, test_labels = [], [], [], []
    for img_path in filenames:
        img_index = int(os.path.basename(img_path).split('_')[1].split('.')[0])
        label = labels[img_index]
        n_faces = np.sum(rois[:, img_index - 1] != 0)
        if n_faces < N_FACES_THRESHOLD:
            continue

        top_left = (int(rois[2, img_index - 1]), int(rois[3, img_index - 1]))
        bottom_right = (int(rois[6, img_index - 1]), int(rois[7, img_index - 1]))
        try:
            img_input = img_preprocessing(img_path, top_left, bottom_right)
        except ValueError as e:
            print(e)
            continue

        if random.random() <= TRAIN_FRAC:
            train_images.append(img_input)
            train_labels.append(label)
        else:
            test_images.append(img_input)
            test_labels.append(label)

    # Convert train and test labels to numpy arrays
    train_labels = np.array(train_labels)
    test_labels = np.array(test_labels)

    # Initialize FaceNet model
    resnet = InceptionResnetV1(pretrained='vggface2').eval()

    # Compute embeddings
    train_images_tensor = torch.stack(train_images)
    test_images_tensor = torch.stack(test_images)
    with torch.no_grad():
        embeddings_train = resnet(train_images_tensor).cpu().numpy()
        embeddings_test = resnet(test_images_tensor).cpu().numpy()

    # Prepare and train SVM classifier
    svm = cv2.ml.SVM_create()
    svm.setType(cv2.ml.SVM_C_SVC)
    svm.setKernel(cv2.ml.SVM_LINEAR)
    svm.setTermCriteria((cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6))
    svm.train(embeddings_train, cv2.ml.ROW_SAMPLE, train_labels)

    # Evaluate SVM on test embeddings
    correct_n = 0
    for i in tqdm(range(len(test_labels))):
        sample = np.array([embeddings_test[i]], dtype=np.float32)
        result = svm.predict(sample)[1].ravel()[0]
        if result == test_labels[i]:
            correct_n += 1

    accuracy = correct_n / len(test_labels)
    print(f"FaceNet + SVM accuracy = {accuracy:.2f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=str, help="Path to the Caltech dataset directory")
    args = parser.parse_args()
    main(args.path)
