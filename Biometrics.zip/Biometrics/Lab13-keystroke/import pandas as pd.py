import pandas as pd

# Load data
data = pd.read_csv("C:\\Users\\nicol\\Desktop\\ERASMUS\\Biometrics\\Lab13-keystroke\\DSL-StrongPasswordData.csv")

# Print the column names
print(data.columns)
