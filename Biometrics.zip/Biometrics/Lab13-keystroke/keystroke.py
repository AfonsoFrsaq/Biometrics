import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.mixture import GaussianMixture

# Step 3: Load the data
data = pd.read_csv(r'c:\Users\anton\Documents\Erasmus\Biometrics\Lab7\DSL-StrongPasswordData.csv')

# Step 4: Extract features and organize data
features = {'KD': {}, 'DDKL': {}, 'UUKL': {}}
subjects = data['subject'].unique()

for subject in subjects:
    subject_data = data[data['subject'] == subject]
    
    # Extract KD (Key Down time) vectors
    kd_vectors = subject_data.filter(regex='H\.').values.tolist()
    
    # Extract DDKL (Down-Down Key Latency) vectors
    ddkl_vectors = subject_data.filter(regex='DD\.').values.tolist()
    
    # Calculate UUKL (Up-Up Key Latency) vectors
    ud_vectors = subject_data.filter(regex='UD\.').values
    h_vectors = subject_data.filter(regex='H\.', axis=1).shift(-1, axis=1).fillna(0).values
    
    # Ensure the shapes match for addition
    if h_vectors.shape[1] > ud_vectors.shape[1]:
        h_vectors = h_vectors[:, :ud_vectors.shape[1]]
    elif h_vectors.shape[1] < ud_vectors.shape[1]:
        ud_vectors = ud_vectors[:, :h_vectors.shape[1]]
    
    uukl_vectors = (ud_vectors + h_vectors).tolist()
    
    features['KD'][subject] = kd_vectors
    features['DDKL'][subject] = ddkl_vectors
    features['UUKL'][subject] = uukl_vectors

# Step 5: Split data into train and test sets
train_test_data = {'train': {'KD': {}, 'DDKL': {}, 'UUKL': {}},
                   'test': {'KD': {}, 'DDKL': {}, 'UUKL': {}}}

for feature in features:
    for subject in features[feature]:
        train_data, test_data = train_test_split(features[feature][subject], test_size=0.2, random_state=42)
        train_test_data['train'][feature][subject] = train_data
        train_test_data['test'][feature][subject] = test_data

# Step 6: Create GMM models and LOOM thresholds
def calculate_loom_threshold(train_vectors, n_components=3):
    N = len(train_vectors)
    scores = np.zeros(N)
    
    for i in range(N):
        loo_vectors = train_vectors[:i] + train_vectors[i+1:]
        gmm = GaussianMixture(n_components=n_components)
        gmm.fit(loo_vectors)
        scores[i] = gmm.score([train_vectors[i]])
    
    threshold = np.percentile(scores, 5)
    return threshold

models = {'KD': {}, 'DDKL': {}, 'UUKL': {}}
thresholds = {'KD': {}, 'DDKL': {}, 'UUKL': {}}

for feature in train_test_data['train']:
    for subject in train_test_data['train'][feature]:
        gmm = GaussianMixture(n_components=3)
        gmm.fit(train_test_data['train'][feature][subject])
        models[feature][subject] = gmm
        
        threshold = calculate_loom_threshold(train_test_data['train'][feature][subject])
        thresholds[feature][subject] = threshold

# Step 7: Test the models
correct_predictions = {'KD': 0, 'DDKL': 0, 'UUKL': 0}
total_predictions = {'KD': 0, 'DDKL': 0, 'UUKL': 0}

for feature in train_test_data['test']:
    for subject in train_test_data['test'][feature]:
        for test_vector in train_test_data['test'][feature][subject]:
            scores = {}
            for other_subject in models[feature]:
                score = models[feature][other_subject].score([test_vector])
                if score >= thresholds[feature][other_subject]:
                    scores[other_subject] = score
            
            if scores:
                predicted_subject = max(scores, key=scores.get)
                if predicted_subject == subject:
                    correct_predictions[feature] += 1
            total_predictions[feature] += 1

accuracy = {feature: correct_predictions[feature] / total_predictions[feature] for feature in correct_predictions}

# Print the accuracy for each feature
print(accuracy)
